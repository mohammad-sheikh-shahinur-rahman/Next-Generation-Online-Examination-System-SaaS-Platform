<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'slug', 'description'];
    
    // Assuming a pivot table: role_permissions
    public function permissions() 
    {
        return $this->belongsToMany(Permission::class, 'role_permissions');
    }
}